extern crate rmp as msgpack;

#[cfg(test)]
#[macro_use]
extern crate quickcheck;

mod func;
